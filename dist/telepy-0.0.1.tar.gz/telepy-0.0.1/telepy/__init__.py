
from telepy import telepy
# from telepy.telepy import Telepy

__all__ = ['telepy']
__version__ = '0.0.1'